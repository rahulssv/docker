[Português Brasileiro](https://www.phpbb.com/customise/db/translation/brazilian_portuguese/)
=============

Versão da Tradução: 1.4.8

Versão do phpBB: 3.3.8


Lista de Tradutores, Colaboradores e Ex-Colaboradores da tradução

Mantedores
-------
* [Chico Gois](https://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=241433)
* [Vinny (Marcus Vinícius)](https://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=1065865)


Colaboradores
-------
* [acdona (Antonio Carlos Doná)](http://www.suportephpbb.com.br/forum/memberlist.php?mode=viewprofile&u=31780)
* [henrique.seven2011 (Saulo Henrique)](https://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=1371157)


Ex-Colaboradores
-------
* [Andre Távora](https://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=302277)
* [jvc94](https://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=1089185)
* [umarizal (Leandro dos Santos)](https://www.phpbb.com/community/memberlist.php?mode=viewprofile&u=512395)
